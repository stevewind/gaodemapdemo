//
//  ViewController.swift
//  mapswift
//
//  Created by stevewinds on 2021/10/14.
//

import UIKit
func delay(_ delayTime: TimeInterval, _ action: @escaping () -> Void){
    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + delayTime, execute: action)
}
class ViewController: UIViewController,MAMapViewDelegate {
    var mapView:MAMapView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.view.backgroundColor = .white
        //创建
        debugPrint("width:",UIScreen.main.bounds.width,"height:",UIScreen.main.bounds.height)
        mapView = MAMapView(frame: CGRect(x: 0.0, y:0, width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height))
        mapView.showsCompass = false
        mapView.delegate = self
        view.addSubview(mapView!)
        self.returnDefaultLoc()
      
    }
    func returnDefaultLoc(){
        let coordinate :CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: 28.184445, longitude: 112.935094)
        self.mapView.centerCoordinate = coordinate
        self.mapView.setZoomLevel(14, animated: true)
    }
    func addYuelushanPoints(){
        let dic1 = ["latitude":28.197877,"longitude":112.930414]
        let dic2 = ["latitude":28.206026,"longitude":112.952117]
        let dic3 = ["latitude":28.187562,"longitude":112.954416]
        let dic4 = ["latitude":28.188963,"longitude":112.947948]
        let dic5 = ["latitude":28.17317,"longitude":112.94838]
        let dic6 = ["latitude":28.179029,"longitude":112.935588]
        let dic7 = ["latitude":28.183486,"longitude":112.929695]
        let dic8 = ["latitude":28.197622,"longitude":112.929551]
        let arr:Array = [dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8]
      
        MapManager.shared().addOverLayMAPolygon(by: mapView, pointsDicArr: arr, customerId: "岳麓山")
   
    }
    func addLieshigongyuanPoints(){
        let dic1 = ["latitude":28.216467,"longitude":112.998397]
        let dic2 = ["latitude":28.224106,"longitude":113.012195]
        let dic3 = ["latitude":28.217231,"longitude":113.014495]
        let dic4 = ["latitude":28.211502,"longitude":113.013489]
        let dic5 = ["latitude":28.210738,"longitude":113.011477]
        let dic6 = ["latitude":28.210738,"longitude":113.006877]
        let dic7 = ["latitude":28.20921,"longitude":112.997535]
        let dic8 = ["latitude":28.21634,"longitude":112.99811]
        let arr:Array = [dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8]
      
        MapManager.shared().addOverLayMAPolygon(by: mapView, pointsDicArr: arr, customerId: "烈士公园")
    }
//    mapDidZoomByUser
    func mapView(_ mapView: MAMapView!, mapDidZoomByUser wasUserAction: Bool) {
        self.addYuelushanPoints()
        self.addLieshigongyuanPoints()
    }
}

