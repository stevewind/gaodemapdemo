//
//  MapManager.m
//  mapT
//
//  Created by stevewinds on 2021/10/14.
//

#import "MapManager.h"


@interface MapManager ()<AMapGeoFenceManagerDelegate>

@property (nonatomic , strong)MAMapView* mapView;
@property (nonatomic , strong)AMapGeoFenceManager *geoFenceManager;

@end
@implementation MapManager


#pragma mark - LifeCycle
+(instancetype)sharedManager {
    static dispatch_once_t onceToken;
    static MapManager *instance;
    dispatch_once(&onceToken, ^{
        instance = [[MapManager alloc] init];
    });
    return instance;
}
#pragma mark - 添加地理围栏和覆盖物
- (void)addOverLayMAPolygonByMapView:(MAMapView*)mapView pointsDicArr:(NSArray *)pointsDicArr customerId:(NSString *)customerId{
    if (!self.geoFenceManager){
        self.geoFenceManager = [AMapGeoFenceManager new];
        self.geoFenceManager.delegate = self;
        self.geoFenceManager.activeAction =AMapGeoFenceActiveActionInside | AMapGeoFenceActiveActionOutside | AMapGeoFenceActiveActionStayed;
    }
    if (!self.mapView){
        self.mapView = mapView;
    }
    CLLocationCoordinate2D *coorArr = malloc(sizeof(CLLocationCoordinate2D) * pointsDicArr.count);
    for(int i =0; i < pointsDicArr.count; i++) {

        CGFloat longitude = [pointsDicArr[i][@"longitude"] doubleValue];

        CGFloat latitude = [pointsDicArr[i][@"latitude"] doubleValue];

        coorArr[i] = CLLocationCoordinate2DMake(latitude, longitude);
    }
    //添加围栏
    [self.geoFenceManager addPolygonRegionForMonitoringWithCoordinates:coorArr count:pointsDicArr.count customID:customerId];
    //添加覆盖物
    [mapView addOverlay:[MAPolygon polygonWithCoordinates:coorArr count:pointsDicArr.count]];
    free(coorArr); //malloc，使用后，记得free
    coorArr = NULL;
   
}
#pragma mark - 清除上一次创建的围栏和其他覆盖物

- (void)clearOverlayers {

    [self.mapView removeOverlays:self.mapView.overlays];  //把之前添加的Overlay都移除掉

    [self.geoFenceManager removeAllGeoFenceRegions];  //移除所有已经添加的围栏，如果有正在请求的围栏也会丢弃

}
#pragma mark - AMapLocationManager Delegate
//申请临时精确定位回调
- (void)amapLocationManager:(AMapGeoFenceManager *)manager doRequireTemporaryFullAccuracyAuth:(CLLocationManager*)locationManager completion:(void(^)(NSError *error))completion{
    
}
#pragma mark - 添加地理围栏完成后的回调

- (void)amapGeoFenceManager:(AMapGeoFenceManager*)manager didAddRegionForMonitoringFinished:(NSArray *)regions customID:(NSString*)customID error:(NSError*)error {

    if([customID isEqualToString:@"polygon_1"]){

        if(error) {

            NSLog(@"=======polygon error %@",error);

        }else{
        //围栏添加后，在地图上的显示，只是为了更方便的演示，并不是必须的.
     
        }
    }
}

/**
 * @brief 根据overlay生成对应的Renderer
 * @param mapView 地图View
 * @param overlay 指定的overlay
 * @return 生成的覆盖物Renderer
 */

- (MAOverlayRenderer *)mapView:(MAMapView *)mapView rendererForOverlay:(id <MAOverlay>)overlay
{
    if ([overlay isKindOfClass:[MATileOverlay class]])
    {
        MATileOverlayRenderer *OverlayRenderer = [[MATileOverlayRenderer alloc] initWithTileOverlay:overlay];
        
        return OverlayRenderer;
    }
    
    if([overlay isKindOfClass:[MAPolygon class]])
        
    {
        
        MAPolygonRenderer *polygon = [[MAPolygonRenderer alloc]initWithPolygon:(MAPolygon*)overlay];
        //边线宽度
        polygon.lineWidth = 3;
        //边线颜色
        polygon.strokeColor = UIColor.greenColor;
        polygon.fillColor = [UIColor colorWithRed:0.0 green:1 blue:0 alpha:0.3];
        polygon.lineJoinType = kMALineJoinRound;
        polygon.lineCapType = kMALineCapRound;
        polygon.lineDashType = kMALineDashTypeSquare;
        return polygon;
    }
    
    
    return nil;
}

#pragma mark - 地理围栏状态改变时回调

- (void)amapGeoFenceManager:(AMapGeoFenceManager*)manager didGeoFencesStatusChangedForRegion:(AMapGeoFenceRegion*)region customID:(NSString*)customID error:(NSError*)error {

    if(error) {

        NSLog(@"status changed error %@",error);

    }else{

//        NSLog(@"status changed %@",[regiondescription]);

    }

    switch(region.fenceStatus) {

        case AMapGeoFenceRegionStatusInside:

        {

            //在区域内

            NSLog(@"在 区域内");

        }

    break;

    case AMapGeoFenceRegionStatusOutside:

    {

    //在区域外

    NSLog(@"在 区域外");

    /////围栏报警超出区域

    

    }

    break;

    case AMapGeoFenceRegionStatusStayed:

    {

    //停留超过十分钟

    }

    break;

    default: {

    //未知

    NSLog(@"在 未知");

    }

    break;

    }

}

@end
