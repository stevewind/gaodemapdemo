//
//  SceneDelegate.h
//  mapT
//
//  Created by stevewinds on 2021/10/13.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

