//
//  MapManager.h
//  mapT
//
//  Created by stevewinds on 2021/10/14.
//

#import <Foundation/Foundation.h>
#import <AMapNaviKit/AMapNaviKit.h>
#import <AMapNaviKit/MAMapKit.h>
#import <AMapNaviKit/MAMapView.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <MapKit/MapKit.h>
NS_ASSUME_NONNULL_BEGIN

@interface MapManager : NSObject
+ (instancetype)sharedManager;

#pragma mark - 添加地理围栏和覆盖物
- (void)addOverLayMAPolygonByMapView:(MAMapView*)mapView pointsDicArr:(NSArray *)pointsDicArr customerId:(NSString *)customerId;

#pragma mark - 清除上一次创建的围栏和其他覆盖物
- (void)clearOverlayers;
@end

NS_ASSUME_NONNULL_END
