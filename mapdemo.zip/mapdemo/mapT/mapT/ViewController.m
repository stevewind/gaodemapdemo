//
//  ViewController.m
//  mapT
//
//  Created by stevewinds on 2021/10/13.
//

#import "ViewController.h"
#import <AMapNaviKit/AMapNaviKit.h>
#import <AMapNaviKit/MAMapKit.h>
#import <AMapNaviKit/MAMapView.h>
#import <AMapFoundationKit/AMapFoundationKit.h>
#import <AMapLocationKit/AMapLocationKit.h>
#import <AMapSearchKit/AMapSearchKit.h>
#import <MapKit/MapKit.h>
#import "MapManager.h"

@interface ViewController ()<MAMapViewDelegate,AMapGeoFenceManagerDelegate>

@property (nonatomic , strong)MAMapView* mapView;
@property (nonatomic , strong)AMapGeoFenceManager *geoFenceManager;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self viewLayout];
    // Do any additional setup after loading the view.
}
- (void)viewLayout{
    
    self.mapView = [[MAMapView alloc]initWithFrame:CGRectMake(0, 0, UIScreen.mainScreen.bounds.size.width, UIScreen.mainScreen.bounds.size.height)];
    self.mapView.showsCompass = NO;
    self.mapView.delegate = self;
    [self.view addSubview:self.mapView];
    [self returnDefaultLoc];

    [self addOverLayerMap];
    [self addOther];
}
-(void)returnDefaultLoc{
    
    CLLocationCoordinate2D  coordinate  = CLLocationCoordinate2DMake(28.184445, 112.935094) ;
    self.mapView.centerCoordinate = coordinate;
    [self.mapView setZoomLevel:14 animated:YES];

}
- (void)addOther{

    NSDictionary *dic1 = @{@"latitude":@(28.216467),@"longitude":@(112.998397)};
    NSDictionary *dic2 = @{@"latitude":@(28.224106),@"longitude":@(113.012195)};
    NSDictionary *dic3 = @{@"latitude":@(28.217231),@"longitude":@(113.014495)};
    NSDictionary *dic4 = @{@"latitude":@(28.211502),@"longitude":@(113.013489)};
    NSDictionary *dic5 = @{@"latitude":@(28.210738),@"longitude":@(113.011477)};
    NSDictionary *dic6 = @{@"latitude":@(28.210738),@"longitude":@(113.006877)};
    NSDictionary *dic7 = @{@"latitude":@(28.20921),@"longitude":@(112.997535)};
    NSDictionary *dic8 = @{@"latitude":@(28.21634),@"longitude":@(112.99811)};
    NSArray *arr = @[dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8];
    [[MapManager sharedManager] addOverLayMAPolygonByMapView:self.mapView pointsDicArr:arr customerId:@"烈士公园"];

}
-(void) addOverLayerMap{
    NSDictionary *dic1 = @{@"latitude":@(28.197877),@"longitude":@(112.930414)};
    NSDictionary *dic2 = @{@"latitude":@(28.206026),@"longitude":@(112.952117)};
    NSDictionary *dic3 = @{@"latitude":@(28.187562),@"longitude":@(112.954416)};
    NSDictionary *dic4 = @{@"latitude":@(28.188963),@"longitude":@(112.947948)};
    NSDictionary *dic5 = @{@"latitude":@(28.17317),@"longitude":@(112.94838)};
    NSDictionary *dic6 = @{@"latitude":@(28.179029),@"longitude":@(112.935588)};
    NSDictionary *dic7 = @{@"latitude":@(28.183486),@"longitude":@(112.929695)};
    NSDictionary *dic8 = @{@"latitude":@(28.197622),@"longitude":@(112.929551)};
    
    
    NSArray *arr = @[dic1,dic2,dic3,dic4,dic5,dic6,dic7,dic8];
  
    [[MapManager sharedManager] addOverLayMAPolygonByMapView:self.mapView pointsDicArr:arr customerId:@"岳麓山"];
               



}


@end
